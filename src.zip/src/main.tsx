import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.tsx'
import 'lenis/dist/lenis.css'
import './globals.css'
import './index.css'

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)
